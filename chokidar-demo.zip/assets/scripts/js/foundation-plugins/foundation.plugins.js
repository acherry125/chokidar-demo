var plugin1 = "car";
var plugin2 = "boat";
var plugin3 = "plane";