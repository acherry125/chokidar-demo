define([], function() {
    return 'module2';
})