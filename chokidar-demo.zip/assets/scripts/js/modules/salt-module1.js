define([], function() {
    var alphabet = ['a', 'b', 'c'];
    return alphabet;
})