// require object exists from the script loading this
require.config({ 

})